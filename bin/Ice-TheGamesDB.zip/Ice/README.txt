Setup:

Run Ice for the first time to create your ROMs directory and to download the
emulators.

================================================================================
Using Ice:

1) Add ROMs into the correct directory based on the console. For example, if you
want to add Super Smash Bros, put the ROM into 'ROMs/N64'.
2) Make sure Steam is closed. If Steam is open, then Ice will do nothing
3) Run Ice again. Make sure that it finishes correctly.
4) Open Steam, and enjoy playing some old games!

================================================================================
Exiting Games:

Hit ESC to exit any of your games. Included with Ice is also a JoyToKey
configuration file. With that, to exit any games just press and hold SELECT,
then press START.

You can download JoyToKey at:
http://www.electracode.com/4/joy2key/JoyToKey%20English%20Version.htm